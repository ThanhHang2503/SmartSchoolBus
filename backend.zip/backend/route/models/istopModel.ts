export interface IStop {
  id: string
  name?: string
  lat: number
  lng: number
  address?: string
  sequence?: number
}

